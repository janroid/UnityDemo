﻿using UnityEngine;
using System.Collections;

public class Tags  {

    public const string player = "Player";
    public const string enemy = "Enemy";
	
}
